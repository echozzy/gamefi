export default {
  /**
   * @description api请求基础路径
   */
  baseUrl: {
    dev: 'http://103.100.210.131:8000/api',
    pro: 'http://103.100.210.131:8000/api'
  },
}
