<template>
  <div class="home">
    <div class="pc-home" style="display: none">
    <page-header></page-header>
    <pc-index></pc-index>
    </div>

    <div class="mobie-home" style="display: none">
      <MobiePageHeader></MobiePageHeader>
      <MobieIndex></MobieIndex>
    </div>
  </div>
</template>

<script>
import PageHeader from '../components/PageHeader.vue'
import PcIndex from '../components/PcIndex.vue';
import MobiePageHeader from "../components/MobiePageHeader";
import MobieIndex from "../components/MobieIndex";

export default {
  name: 'Home',
  components:{
    PageHeader,
    PcIndex,
    MobiePageHeader,
    MobieIndex,
  },
  setup(){
    
  },
}
</script>

<style lang="less">
  @media screen and (min-width: 857px){
    .home{
      background: #000000;
      .pc-home{
        display: block!important;
      }
    }
  }
  @media screen and (max-width: 856px) {
    .home{
      background: #000000;
      .mobie-home{
        display: block!important;
      }
    }
  }
</style>
