<template>
  <div class="mobie-index" @scroll="menu">
      <section class="section">
        <div class="banner-con">
          <div class="banner-img">
            <img src="../assets/mobie/mobie-bannar.png" alt="" />
          </div>
        </div>
      </section>
      <section class="section">
        <div class="section-item play-con flex-fc flex-ac">
          <div class="title">
            <p class="title-bg">PLAY THE GAME</p>
            <p class="title-top">GAME PLAY</p>
          </div>
          <div :class="rolls.value == 2? 'item-play fadeInRight animated go' : 'item-play'">
            <swiper
              :modules="modules"
              :loop="true"
              :space-between="50"
              @swiper="onSwiper"
              @slideChange="onSlideChange"
            >
              <swiper-slide>
                <div class="game-play-img">
                  <div class="play-logos"><img src="../assets/mobie/paly-logos.png"></div>
                  <div class="play-bg"><img src="../assets/mobie/mobie-play-bg.png"></div>
                  <div class="play-icons"><img src="../assets/home/play_wf1.png"></div>
                  <div class="play-title">
                    <p class="title-bg">4V4</p>
                    <p class="title-top">BTATTLE ROALE</p>
                  </div>
                  <div class="play-content">
                    <div class="content-cent">
                    <p>Star Battle is the main 3V3 battle mode of Nova Battles. It is a desperate battle around the battle for Stars.</p>
                    <p> Be the first to collect more than ten Stars and maintain the advantage until the countdown ends to win.</p>
                    </div>
                  </div>
                </div>
              </swiper-slide>
              <swiper-slide>
                <div class="game-play-img">
                  <div class="play-logos"><img src="../assets/mobie/paly-logos.png"></div>
                  <div class="play-bg"><img src="../assets/mobie/mobie-play-bg.png"></div>
                  <div class="play-icons"><img src="../assets/home/play_wf2.png"></div>
                  <div class="play-title">
                    <p class="title-bg">4V4</p>
                    <p class="title-top">BTATTLE ROALE</p>
                  </div>
                  <div class="play-content">
                    <div class="content-cent">
                      <p>Star Battle is the main 3V3 battle mode of Nova Battles. It is a desperate battle around the battle for Stars.</p>
                      <p> Be the first to collect more than ten Stars and maintain the advantage until the countdown ends to win.</p>
                    </div>
                  </div>
                </div>
              </swiper-slide>
              <swiper-slide>
                <div class="game-play-img">
                  <div class="play-logos"><img src="../assets/mobie/paly-logos.png"></div>
                  <div class="play-bg"><img src="../assets/mobie/mobie-play-bg.png"></div>
                  <div class="play-icons"><img src="../assets/home/play_wf3.png"></div>
                  <div class="play-title">
                    <p class="title-bg">4V4</p>
                    <p class="title-top">BTATTLE ROALE</p>
                  </div>
                  <div class="play-content">
                    <div class="content-cent">
                      <p>Star Battle is the main 3V3 battle mode of Nova Battles. It is a desperate battle around the battle for Stars.</p>
                      <p> Be the first to collect more than ten Stars and maintain the advantage until the countdown ends to win.</p>
                    </div>
                  </div>
                </div>
              </swiper-slide>
              <swiper-slide>
                <div class="game-play-img">
                  <div class="play-logos"><img src="../assets/mobie/paly-logos.png"></div>
                  <div class="play-bg"><img src="../assets/mobie/mobie-play-bg.png"></div>
                  <div class="play-icons"><img src="../assets/home/play_wf4.png"></div>
                  <div class="play-title">
                    <p class="title-bg">4V4</p>
                    <p class="title-top">BTATTLE ROALE</p>
                  </div>
                  <div class="play-content">
                    <div class="content-cent">
                      <p>Star Battle is the main 3V3 battle mode of Nova Battles. It is a desperate battle around the battle for Stars.</p>
                      <p> Be the first to collect more than ten Stars and maintain the advantage until the countdown ends to win.</p>
                    </div>
                  </div>
                </div>
              </swiper-slide>
              <swiper-slide>
                <div class="game-play-img">
                  <div class="play-logos"><img src="../assets/mobie/paly-logos.png"></div>
                  <div class="play-bg"><img src="../assets/mobie/mobie-play-bg.png"></div>
                  <div class="play-icons"><img src="../assets/home/play_wf5.png"></div>
                  <div class="play-title">
                    <p class="title-bg">4V4</p>
                    <p class="title-top">BTATTLE ROALE</p>
                  </div>
                  <div class="play-content">
                    <div class="content-cent">
                      <p>Star Battle is the main 3V3 battle mode of Nova Battles. It is a desperate battle around the battle for Stars.</p>
                      <p> Be the first to collect more than ten Stars and maintain the advantage until the countdown ends to win.</p>
                    </div>
                  </div>
                </div>
              </swiper-slide>
              <swiper-slide>
                <div class="game-play-img">
                  <div class="play-logos"><img src="../assets/mobie/paly-logos.png"></div>
                  <div class="play-bg"><img src="../assets/mobie/mobie-play-bg.png"></div>
                  <div class="play-icons"><img src="../assets/home/play_wf6.png"></div>
                  <div class="play-title">
                    <p class="title-bg">4V4</p>
                    <p class="title-top">BTATTLE ROALE</p>
                  </div>
                  <div class="play-content">
                    <div class="content-cent">
                      <p>Star Battle is the main 3V3 battle mode of Nova Battles. It is a desperate battle around the battle for Stars.</p>
                      <p> Be the first to collect more than ten Stars and maintain the advantage until the countdown ends to win.</p>
                    </div>
                  </div>
                </div>
              </swiper-slide>
<!--              <swiper-slide>-->
<!--                <div class="game-play-img">-->
<!--                  <div class="img-bg-left">-->
<!--                    <img src="../assets/home/game-play-img.png" alt="" />-->
<!--                  </div>-->
<!--                  <div class="img-bg-right">-->
<!--                    <div class="bg-right-title"><img src="../assets/home/title-top4.png"></div>-->
<!--                    <div class="bg-right-icon"><img src="../assets/home/play_wf7.png"></div>-->
<!--                    <div class="bg-right-nav">Runaway Monster</div>-->
<!--                    <div class="bg-right-cont">Players need to work together to protect the city from monsters.-->
<!--                      <br/>-->
<!--                      If all buildings are destroyed or all heroes are defeated, the monster wins.</div>-->
<!--                  </div>-->
<!--                </div>-->
<!--              </swiper-slide>-->
              <div class="paly-pagination-con">
                <div class="pagination">
                  <span class="my-bullet" :class="nowActive==0?'my-bullet-active':''" @click="toSlide(1)"></span>
                  <span class="my-bullet" :class="nowActive==1?'my-bullet-active':''" @click="toSlide(2)"></span>
                  <span class="my-bullet" :class="nowActive==2?'my-bullet-active':''" @click="toSlide(3)"></span>
                  <span class="my-bullet" :class="nowActive==3?'my-bullet-active':''" @click="toSlide(4)"></span>
                  <span class="my-bullet" :class="nowActive==4?'my-bullet-active':''" @click="toSlide(5)"></span>
                  <span class="my-bullet" :class="nowActive==5?'my-bullet-active':''" @click="toSlide(6)"></span>
                </div>
              </div>
            </swiper>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="section-item role-con flex-fc flex-ac">
          <div class="title">
            <p class="title-bg">PLAY THE GAME</p>
            <p class="title-top">HERO INTRODUCTION</p>
          </div>
          <div  :class="rolls.value == 3 ? 'item-role-con fadeInRight animated go' : 'item-role-con'">
            <swiper
              :modules="modules"
              :slidesPerView="2"
              :grid="{rows:2,fill:'row'}"
              @swiper="onTwoSwiper"
              @slideChange="onTwoSlideChange"
            >
              <swiper-slide v-for="item in lists" v-bind:key="item">
                <div class="role-item">
                  <img :src="item.imgUrl" alt="" />
                </div>
              </swiper-slide>
              <div class="pagination-con">
                <div class="pagination" style="justify-content: center">
                  <span class="my-bullet" :class="twoNowActive==0?'my-bullet-active':''" @click="twoToSlide(1)"></span>
                  <span class="my-bullet" :class="twoNowActive==1?'my-bullet-active':''" @click="twoToSlide(2)"></span>
                  <span class="my-bullet" :class="twoNowActive==2?'my-bullet-active':''" @click="twoToSlide(3)"></span>
                  <span class="my-bullet" :class="twoNowActive==3?'my-bullet-active':''" @click="twoToSlide(4)"></span>
                  <span class="my-bullet" :class="twoNowActive==4?'my-bullet-active':''" @click="twoToSlide(5)"></span>
                  <span class="my-bullet" :class="twoNowActive==5?'my-bullet-active':''" @click="twoToSlide(6)"></span>
                </div>
              </div>
            </swiper>
          </div>
        </div>
      </section>
      <section class="section">
        <div  :class="rolls.value == 4 ? 'shiba-con fadeIn animatedtwo go' : 'shiba-con'">
          <div class="shiba-txt-left">
            <div class="shiba-left-logo">
              <img src="../assets/mobie/goutou-bg.png">
            </div>
            <div class="txt-title">
              <div class="title-top">
                <img src="../assets/home/shiba-title2.png" alt="" />
              </div>
              <p class="title-bottom">Our History and ShibaInu</p>
            </div>
            <div class="txt-content">
              <div class="content-top">
                &nbsp;&nbsp;&nbsp;&nbsp;Our whole team are all investors of ShibaInu. Our team has a little bit of everything. Some are fresh crypto investors but avid gamers, others have been investing and trading since 2010.
              </div>
              <div class="content-mid">
                <div class="content-line"></div>
              </div>
              <div class="content-bottom">
                &nbsp;&nbsp;&nbsp;&nbsp;We want the Shibarmy to grow and have incorporated an in-game system that BURNS Shiba tokens throughout the lifespan of this game. We are one with the people and we want the people to play, earn, and create together.
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="section-item links-con flex-fc flex-ac">
          <div class="title">
            <p class="title-bg">PLAY THE GAME</p>
            <p class="title-top">PARTNER</p>
          </div>
          <div class="item-links-con">
            <div  :class="rolls.value == 5 ? 'links-item-con fadeInDownShort animatedtwo go':'links-item-con'">
              <div class="links-item">
                <img src="../assets/home/links-item2.png" alt="" />
              </div>
              <div class="links-item links-item-mid">
                <img src="../assets/home/links-item1.png" alt="" />
              </div>
              <div class="links-item">
                <img src="../assets/home/links-item3.png" alt="" />
              </div>
            </div>
            <div class="title" style="margin-top: 20px;width: 100%">
              <p class="title-bg" style="transform: scale(0.6);">Subscription message</p>
              <p class="title-top" style="transform: scale(0.5);">Subscription message</p>
            </div>
            <div class="links-inp-con">
              <div class="inp-title">ARE YOU READY TO START YOUR JOURNEY?</div>
              <div class="inp-con">
                <div style="width: 100%;display: flex;justify-content: center;">
                  <input
                          class="inp"
                          type="email"
                          placeholder="Enter Meail Address"
                  />
                </div>
                <div class="inp-btn" @click="subscribe">SUBMIT</div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="community-con flex-fc">
          <div class="community-logo flex">
            <img src="../assets/home/community-logo.png" alt="" />
            <span>JOIN OUR COMMUNITY</span>
          </div>
          <div class="community-item-con flex">
            <div class="community-icon">
              <a class="icon-sty iconimga" href="https://twitter.com/NoVaBattles" target="_blank">
              </a>
            </div>
            <div class="community-icon">
              <a class="icon-sty iconimgb" href="https://discord.io/NoVaBattles" target="_blank">
              </a>
            </div>
            <div class="community-icon">
              <a class="icon-sty iconimgc" href="https://www.instagram.com/nova.battles/" target="_blank">
              </a>
            </div>
            <div class="community-icon">
              <a class="icon-sty iconimgd" href="https://www.facebook.com/NoVaBattles" target="_blank">
              </a>
            </div>
            <div class="community-icon">
              <a class="icon-sty iconimge" href="https://www.reddit.com/r/NoVaBattles" target="_blank">
              </a>
            </div>
            <div class="community-icon">
              <a class="icon-sty iconimgf" href="https://t.me/NoVaBattles" target="_blank">
              </a>
            </div>
            <div class="community-icon">
              <a class="icon-sty iconimgg" href="https://novabattles.medium.com" target="_blank">
              </a>
            </div>
          </div>
          <div class="community-download flex">
            <span class="community-download-span flex">DOWNLOAD GAME APP</span>
            <a class="community-download-app flex">
              <img src="../assets/home/community-download-video.png" alt="" />
            </a>
            <a class="community-download-app flex">
              <img src="../assets/home/community-download-apple.png" alt="" />
            </a>
            <a class="community-download-app flex">
              <img src="../assets/home/community-download-android.png" alt="" />
            </a>
          </div>
          <div class="community-bottom-menus flex">
            <div class="menus-nav">
              <a href="https://wp.novabattles.com/" target="_blank">
              <p class="menus-nav-txt">WHITEPAPER</p>
              </a>
            </div>
            <div class="menus-nav">
              <a href="javascript:void(0)">
              <p class="menus-nav-txt">CONTACT US</p>
              </a>
            </div>
            <div class="menus-nav">
              <a href="https://wp.novabattles.com/faqs/terms-of-use" target="_blank">
              <p class="menus-nav-txt">Terms Of Use</p>
              </a>
            </div>
            <div class="menus-nav">
              <a href="https://wp.novabattles.com/faqs/privacy-policy" target="_blank">
              <p class="menus-nav-txt">Privacy Policy</p>
              </a>
            </div>
          </div>
          <div class="community-copyright">
            <p>ESLA TECHNOLOGY PTE.LTD. © 2021, All rights reserved</p>
          </div>
        </div>
      </section>
      <div :class="rolls.value == 6 ? 'section-list section-active' : 'section-list'">
      <div class="banner-list-bg">
        <div class="list-bg-nav"><img src="../assets/mobie/mobie-nav.png"></div>
        <div class="list-con">
          <img src="../assets/mobie/nav-lista.png"> <span>|</span>
          <img src="../assets/mobie/nav-listb.png"> <span>|</span>
          <img src="../assets/mobie/nav-listc.png"> <span>|</span>
          <img src="../assets/mobie/nav-listd.png"> <span>|</span>
          <img src="../assets/mobie/nav-liste.png">
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {ref, reactive, onMounted} from "vue";

// import Swiper core and required modules
import { Navigation, Pagination, Autoplay,Grid } from "swiper";
// Import Swiper Vue.js components
import { Swiper, SwiperSlide } from "swiper/vue/swiper-vue";
// Import Swiper styles
import "swiper/swiper.min.css";
import "swiper/modules/grid/grid.min.css"
export default {
  components: {
    Swiper,
    SwiperSlide,
  },
  name: "MobiePcIndex",
  data(){
    return{
      lists:[
        { id:1,imgUrl:require('../assets/home/role1.png')},
        { id:2,imgUrl:require('../assets/home/role2.png')},
        { id:3,imgUrl:require('../assets/home/role3.png')},
        { id:4,imgUrl:require('../assets/home/role4.png')},
        { id:5,imgUrl:require('../assets/home/role1.png')},
        { id:6,imgUrl:require('../assets/home/role2.png')},
        { id:7,imgUrl:require('../assets/home/role3.png')},
        { id:8,imgUrl:require('../assets/home/role4.png')},
        { id:9,imgUrl:require('../assets/home/role1.png')},
        { id:10,imgUrl:require('../assets/home/role2.png')},
        { id:11,imgUrl:require('../assets/home/role3.png')},
        { id:12,imgUrl:require('../assets/home/role4.png')},
        { id:13,imgUrl:require('../assets/home/role1.png')},
        { id:14,imgUrl:require('../assets/home/role2.png')},
        { id:15,imgUrl:require('../assets/home/role3.png')},
        { id:16,imgUrl:require('../assets/home/role4.png')},
        { id:17,imgUrl:require('../assets/home/role1.png')},
        { id:18,imgUrl:require('../assets/home/role2.png')},
        { id:19,imgUrl:require('../assets/home/role3.png')},
        { id:20,imgUrl:require('../assets/home/role4.png')},
        { id:21,imgUrl:require('../assets/home/role1.png')},
        { id:22,imgUrl:require('../assets/home/role2.png')},
        { id:23,imgUrl:require('../assets/home/role3.png')},
        { id:24,imgUrl:require('../assets/home/role4.png')},
      ],
      sroll:'',
    }
  },
  setup() {
    //屏幕滚动参数
    onMounted(() => {
      window.addEventListener("scroll", dataroll, true)
    })
    const isScroll = ref(false);
    const rolls = reactive({
      value: 0,
    });

    function dataroll() {
      if (isScroll.value) {
        return;
      }
      isScroll.value = true;
      setTimeout(() => {
        isScroll.value = false;
      }, 0);
      //滚动条的高度
      const clientHeight = document.documentElement.clientHeight;
      const scrollTop =  document.documentElement.scrollTop;
      //滚动条的高度>可视区的高度

      // console.log(clientHeight*2+clientHeight/10);
      // console.log(scrollTop);
      // console.log(clientHeight*4);

      if(scrollTop > clientHeight*4){
        rolls.value = 6;
      }else if(scrollTop > clientHeight*3+clientHeight/5  && scrollTop < clientHeight*5-clientHeight/10){
        rolls.value = 5;
      }else if(scrollTop > clientHeight*2+clientHeight/5  && scrollTop < clientHeight*4-clientHeight/10){
        rolls.value = 4;
      }else if(scrollTop > clientHeight+clientHeight/5  && scrollTop < clientHeight*3-clientHeight/10){
        rolls.value = 3;
      }else if(scrollTop > clientHeight/5  && scrollTop < clientHeight*2-clientHeight/10){
        rolls.value = 2;
      }else{
        rolls.value = 0;
      }
    }

    // 定义swiper参数
    let firstSwiper = null
    const nowActive = ref(0)
    const onSwiper = (swiper) => {
      firstSwiper = swiper
    };
    const onSlideChange = (firstSwiper) => {
      nowActive.value = firstSwiper.realIndex
    };
    function toSlide(index) {
      let all_num = firstSwiper.slides.length-3
      if(index==1&&firstSwiper.realIndex==all_num){
        firstSwiper.slideNext()
        nowActive.value = firstSwiper.realIndex
        return
      }
      if(index==6&&firstSwiper.realIndex==0){
        firstSwiper.slidePrev()
        nowActive.value = firstSwiper.realIndex
        return
      }
      firstSwiper.slideTo(index)
      nowActive.value = firstSwiper.realIndex
    }

    let twoSwiper = null
    const twoNowActive = ref(0)
    const onTwoSwiper = (swiper) => {
      twoSwiper = swiper
    };
    const onTwoSlideChange = (twoSwiper) => {
      if(twoSwiper.activeIndex<2){
        twoNowActive.value = 0
      }
      if(twoSwiper.activeIndex>=2&&twoSwiper.activeIndex<4){
        twoNowActive.value = 1
      }
      if(twoSwiper.activeIndex>=4&&twoSwiper.activeIndex<6){
        twoNowActive.value = 2
      }
      if(twoSwiper.activeIndex>=6&&twoSwiper.activeIndex<8){
        twoNowActive.value = 3
      }
      if(twoSwiper.activeIndex>=8&&twoSwiper.activeIndex<10){
        twoNowActive.value = 4
      }
      if(twoSwiper.activeIndex>=10&&twoSwiper.activeIndex<12){
        twoNowActive.value = 5
      }
    };
    function twoToSlide(index) {
      if(index==1){
        twoSwiper.slideTo(0)
        twoNowActive.value = 0
      }
      if(index==2){
        twoSwiper.slideTo(2)
        twoNowActive.value = 1
      }
      if(index==3){
        twoSwiper.slideTo(4)
        twoNowActive.value = 2
      }
      if(index==4){
        twoSwiper.slideTo(6)
        twoNowActive.value = 3
      }
      if(index==5){
        twoSwiper.slideTo(8)
        twoNowActive.value = 4
      }
      if(index==6){
        twoSwiper.slideTo(10)
        twoNowActive.value = 5
      }
    }
    return {
      rolls,
      modules: [Navigation, Autoplay, Pagination,Grid],
      onSwiper,onSlideChange,toSlide,firstSwiper,nowActive,
      twoNowActive,onTwoSwiper,onTwoSlideChange,twoToSlide
    };
  },
  methods:{

  },
};
</script>

<style lang="less">
@media screen and (min-width: 0px) and (max-width: 856px){
  @font-face {
    font-family: NovaBattle;
    src: url("../assets/font/novabattlePro.ttf");
  }
  .mobie-index {
    width: 100%;
    position: relative;
    .section {
      width: 100%;
      height: 16.54rem;
      display: flex;
      justify-content: center;
      background: url(../assets/mobie/mobie-gb.png) no-repeat;
      background-size: 95% 98%;
      background-attachment:fixed;
      background-position:center;
    .section-item {
      width: 100%;
      justify-content: center;
    }
    .banner-con {
      position: relative;
      width: 100%;
      box-sizing: border-box;
      display: flex;
      justify-content: center;
      .banner-img {
        width: 100%;
        text-align: center;
        img {
          width: 96%;
          height: 99%;
        }
      }
    }
    .pagination-con {
      display: flex;
      align-items: center;
      position: relative;
      margin-top: 1rem;
      z-index: 2;
      .pagination {
        display: flex;
        width: 8rem;
        margin: 0 0.2rem;
        .my-bullet {
          background: url(../assets/home/swiper-slide.png) no-repeat;
          background-size: 100% 100%;
          width: 0.86rem;
          height:0.1rem;
          cursor: pointer;
        }
        .my-bullet-active {
          background: url(../assets/home/swiper-slide-active.png) no-repeat;
          background-size: 100% 100%;
          width: 0.86rem;
          height: 0.1rem;
        }
      }
      .swiper-button-prev,
      .swiper-button-next {
        display: flex;
      }
      .swiper-grid > .swiper-wrapper {
        flex-wrap: wrap;
      }
      .swiper-grid-column > .swiper-wrapper {
        flex-wrap: wrap;
        flex-direction: column;
      }
    }
    .play-con {
      .title {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        .title-bg {
          position: relative;
          z-index: 1;
          color: rgba(216, 216, 216, 0);
          font-size: 0.8rem;
          font-family: NovaBattle;
          opacity: 0.75;
          -webkit-text-stroke: 2px rgba(113, 153, 192, 0.25);
        }
        .title-top {
          font-family: NovaBattle;
          position: absolute;
          font-size: 0.36rem;
          font-weight: 800;
          color: #8ec4f9;
          letter-spacing: 3px;
          text-shadow: 0px 0px 40px #8ec4f9;
        }
      }
      .item-play {
        width: 7.54rem;
        position: relative;
        .swiper{
          width: 100%;
        }
        .game-play-img{
          display: flex;
          flex-wrap: wrap;
          position: relative;
          margin-top: 0.8rem;
          justify-content: center;
          .play-logos{
            position: absolute;
            width: 7.3rem;
            bottom: 3.7rem;
          }
          .play-bg{
            width: 7.54rem;
            height: 7.92rem;
          }
          .play-icons{
            position: absolute;
            width: 1.3rem;
            height: 0.16rem;
            text-align: center;
            top: 3.5rem;
          }
          .play-title {
            width: 100%;
            position: absolute;
            display: flex;
            justify-content: center;
            align-items: center;
            top: 4.3rem;
            .title-bg {
              position: relative;
              z-index: 1;
              color: rgba(216, 216, 216, 0);
              font-size: 1.6rem;
              font-family: NovaBattle;
              opacity: 0.75;
              -webkit-text-stroke: 2px rgba(113, 153, 192, 0.25);
            }
            .title-top {
              font-family: NovaBattle;
              position: absolute;
              font-size: 0.6rem;
              font-weight: 800;
              color: #8ec4f9;
              letter-spacing: 0.05rem;
              text-shadow: 0px 0px 40px #8ec4f9;
            }
          }
          .play-content{
            width: 5.2rem;
            height: 1.6rem;
            position:absolute;
            display: flex;
            justify-content: center;
            top: 6rem;
            overflow-y: hidden;
            .content-cent{
              font-size: 0.12rem;
              color: #fff;
              text-align: center;
            }
          }
        }
        .paly-pagination-con {
          display: flex;
          align-items: center;
          position: relative;
          z-index: 2;
          margin-top:0.5rem;
          .pagination {
            display: flex;
            justify-content: center;
            width: 8rem;
            .my-bullet {
              background: url(../assets/home/swiper-slide.png) no-repeat;
              background-size: 100% 100%;
              width: 0.86rem;
              height: 0.1rem;
              cursor: pointer;
            }
            .my-bullet-active {
              background: url(../assets/home/swiper-slide-active.png) no-repeat;
              background-size: 100% 100%;
              width: 0.86rem;
              height: 0.1rem;
            }
          }
          .swiper-button-prev,
          .swiper-button-next {
            display: flex;
          }
        }
      }
    }
    .role-con {
      .title {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        .title-bg {
          position: relative;
          z-index: 1;
          color: rgba(216, 216, 216, 0);
          font-size: 0.8rem;
          font-family: NovaBattle;
          opacity: 0.75;
          -webkit-text-stroke: 2px rgba(113, 153, 192, 0.25);
        }
        .title-top {
          font-family: NovaBattle;
          position: absolute;
          font-size: 0.36rem;
          font-weight: 800;
          color: #8ec4f9;
          letter-spacing: 3px;
          text-shadow: 0px 0px 40px #8ec4f9;
        }
      }
      .item-role-con {
        width: 7.54rem;
        .role-item {
          width: 2.6rem;
          height: 4.7rem;
        }
          .swiper-slide{
            display: flex;
            justify-content: center;
          }
      }
    }
    .shiba-con {
      width: 8.2rem;
      display: flex;
      align-items: center;
      justify-content: center;
      position: relative;
      .shiba-txt-left {
        width: 8.2rem;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        .shiba-left-logo{
          width: 4.6rem;
          height: 4rem;
        }
        .txt-title {
          position: relative;
          margin-bottom: 0.2rem;
          .title-top {
            display: flex;
            width: 5.8rem;
            height: 0.44rem;
          }
          .title-bottom {
            position: relative;
            color: rgba(255, 164, 9, 1);
            font-size: 0.26rem;
            text-shadow: 0px 0px 20px #ffa409;
            margin-top: -0.1rem;
            font-family: NovaBattle;
            white-space: nowrap;
            letter-spacing: 0.1rem;
            line-height: 0.5rem;
            text-align: center;
          }
        }
        .txt-content {
          display: flex;
          flex-wrap: wrap;
          justify-content: center;
          width: 8.2rem;
          .content-top {
            width: 5.7rem;
            font-size: 0.2rem;
            font-family: NovaBattle;
            font-weight: 800;
            color: #ffffff;
            line-height: 0.5rem;
            text-align: center;
          }
          .content-mid {
            width: 5.7rem;
            .content-line{
              width: 1.7rem;
              height: 0.05rem;
              background: #ffa409;
              margin: 0.3rem auto;
            }
          }
          .content-bottom {
            width: 5.7rem;
            font-size: 0.2rem;
            font-family: NovaBattle;
            opacity: 0.5;
            font-weight: 800;
            color: #ffffff;
            line-height: 0.5rem;
            text-align: center;
          }
        }
      }
    }
    .links-con {
      .title {
        position: relative;
        display: flex;
        justify-content: center;
        align-items: center;
        .title-bg {
          position: relative;
          z-index: 1;
          color: rgba(216, 216, 216, 0);
          font-size:0.8rem;
          font-family: NovaBattle;
          opacity: 0.75;
          -webkit-text-stroke: 2px rgba(113, 153, 192, 0.25);
        }
        .title-top {
          font-family: NovaBattle;
          position: absolute;
          font-size: 0.36rem;
          font-weight: 800;
          color: #8ec4f9;
          letter-spacing: 0.1rem;
          text-shadow: 0px 0px 40px #8ec4f9;
        }
      }
      .item-links-con {
        width: 100%;
        display: flex;
        justify-content: center;
        flex-wrap: wrap;
        .links-item-con {
          display: flex;
          justify-content: center;
          flex-wrap: wrap;
          width: 45%;
          .links-item{
            width: 5rem;
            margin-top: 30px;
          }
        }
        .links-inp-con {
          background: url(../assets/home/links-inp-con-bg.png) no-repeat;
          background-size: 100% 100%;
          width: 7.6rem;
          height: 2.8rem;
          margin-top: 0.2rem;
          .inp-title {
            font-size: 0.12rem;
            font-family: NovaBattle;
            font-weight: 800;
            color: #ffffff;
            line-height: 0.5rem;
            display: flex;
            justify-content: center;
            margin-top: 0.5rem;
          }
          .inp-con {
            width: 100%;
            display: flex;
            justify-content: center;
            flex-wrap: wrap;
            margin-top: 0.2rem;
            .inp {
              width: 6.1rem;
              height: 0.54rem;
              font-size: 0.16rem;
              font-weight: 800;
              color: #DEDEDE;
              text-align: center;
            }
            input {
              outline-style: none;
              border: 1px solid #43576fcc;
              border-right: 0;
              padding: 0.1rem 1.6rem;
              color: #131313;
              background: #ffffff;
              border-radius: 4px;
            }
            input:focus {
              border-color: #66afe9;
              outline: 0;
              -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075),
              0 0 8px rgba(102, 175, 233, 0.6);
              box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075),
              0 0 8px rgba(102, 175, 233, 0.6);
            }
            .inp-btn {
              background: url("../assets/mobie/anniu-bg.png") no-repeat;
              background-size: 100% 100%;
              width: 2.4rem;
              height: 0.6rem;
              font-size: 0.13rem;
              font-family: NovaBattle;
              font-weight: 800;
              color: #ffffff;
              display: flex;
              justify-content: center;
              align-items: center;
              margin-top: 0.2rem;
            }
          }
        }
      }
      .item-links-contwo{
        width: 100%;
      }
    }
    .community-con {
      align-items: center;
      justify-content: center;
      .community-logo {
        justify-content: center;
        flex-wrap: wrap;
        img{
          width: 8rem;
          height: 4rem;
        }
        span{
          width: 100%;
          height:0.24rem;
          font-size: 0.24rem;
          font-family: Blender Pro;
          font-weight: 800;
          color: #FFFFFF;
          text-align: center;
          margin-bottom:0.3rem;
        }
      }
      .community-download {
        display: flex;
        flex-wrap: wrap;
        flex-flow: column;
        align-items: center;
        .community-download-app{
          width: 2.6rem;
          height: 1rem;
          justify-content: center;
          margin-top: 0.2rem;
        }
        .community-download-span{
          width: 100%;
          font-size: 0.24rem;
          font-family: Blender Pro;
          font-weight: 800;
          color: #FFFFFF;
          justify-content: center;
          line-height: 0.5rem;
          margin: 0.3rem 0;
        }
      }
      .community-item-con {
        width: 58%;
        justify-content: center;
        flex-wrap: wrap;
        .community-icon {
          display: flex;
          margin-left: 0.15rem;
          margin-top: 0.15rem;
          .icon-sty{
            display: block;
            width: 0.88rem;
            height: 0.88rem;
          }
          .iconimga{
            background: url("../assets/home/community-icon1.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimga:hover{
            background: url("../assets/home/community-icon1-hover.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimgb{
            background: url("../assets/home/community-icon2.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimgb:hover{
            background: url("../assets/home/community-icon2_hover.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimgc{
            background: url("../assets/home/community-icon3.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimgc:hover{
            background: url("../assets/home/community-icon3_hover.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimgd{
            background: url("../assets/home/community-icon4.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimgd:hover{
            background: url("../assets/home/community-icon4_hover.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimge{
            background: url("../assets/home/community-icon5.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimge:hover{
            background: url("../assets/home/community-icon5_hover.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimgf{
            background: url("../assets/home/community-icon6.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimgf:hover{
            background: url("../assets/home/community-icon6_hover.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimgg{
            background: url("../assets/home/community-icon7.png") no-repeat;
            background-size: 100% 100%;
          }
          .iconimgg:hover{
            background: url("../assets/home/community-icon7_hover.png") no-repeat;
            background-size: 100% 100%;
          }
        }
      }
      .community-copyright {
        width: 42%;
        margin: 0.5rem 0;
        p {
          text-align: center;
          font-size: 0.18rem;
          font-family: NovaBattle;
          font-weight: 800;
          color: rgba(151, 151, 151, 1);
          line-height: 0.3rem;
        }
      }
      .community-bottom-menus {
        width: 58%;
        display: flex;
        flex-wrap: wrap;
        margin-top: 0.1rem;
        .menus-nav {
          width: 100%;
          display: flex;
          justify-content: center;
          margin-top: 0.3rem;
          .menus-nav-icon {
            margin-right: 13px;
            width: 10px;
            height: 15px;
          }
          .menus-nav-txt {
            font-family: NovaBattle;
            font-size: 0.24rem;
            font-weight: 800;
            color: #6d9bbf;
          }
          .menus-nav-txt:hover{
            color: #fff;
          }
        }
      }
    }
    }
    .section-list{
      width: 8.56rem;
      height: 0.79rem;
      display: flex;
      justify-content: center;
      position: fixed;
      bottom: 0.9rem;
      z-index: 99;
      .banner-list-bg{
        width: 5.3rem;
        height: 0.79rem;
        display: flex;
        justify-content: center;
        .list-bg-nav{
          width: 5.3rem;
          position: absolute;
          height: 0.79rem;
          opacity: 0.25;
          display: flex;
          justify-content: center;
        }
        .list-con{
          height: 0.79rem;
          display: flex;
          justify-content: center;
          align-items: center;
          color: white;
          span{
            display: block;
            padding: 0 0.2rem;
            font-size: 0.2rem;
            line-height:0.79rem;
          }
          img{
            width:0.54rem;
            height: 0.54rem;
          }
        }
      }
    }
    .section-active{
      display: none;
    }
  }

  /*动画-start*/
  .fadeInRight.go {
    -webkit-animation-name: fadeInRight;
    animation-name: fadeInRight;
  }
  .fadeInRight {
    opacity: 0;
    -webkit-transform: translateX(0);
    transform: translateX(0);
  }
  .fadeIn.go{
    -webkit-animation-name: fadeIn;
    animation-name: fadeIn;
  }
  .fadeIn {
    opacity: 0;
  }
  .fadeInDownShort.go{
    -webkit-animation-name: fadeInDownShort;
    animation-name: fadeInDownShort;
  }
  .fadeInDownShort{
    opacity: 0;
    -webkit-transform: translateY(-30px);
    transform: translateY(-30px);
  }
  .animated{
    -webkit-animation-duration:0.7s;
    animation-duration: 0.7s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
  }
  .animatedtwo{
    -webkit-animation-duration:0.7s;
    animation-duration: 2s;
    -webkit-animation-fill-mode: both;
    animation-fill-mode: both;
  }
  @keyframes fadeInRight {
    0%{
      opacity: 0;
      transform: translateX(0);
    }
    100%{
      opacity: 1;
      transform: translateX(0);
    }
  }
  @keyframes fadeIn{
    0%{
      opacity: 0;
    }
    10%{
      opacity: 0.1;
    }
    20%{
      opacity: 0.2;
    }
    100%{
      opacity: 1;
      display: block;
    }
  }
  @keyframes fadeInDownShort{
    0%{
      opacity: 0;
      transform: translateY(-30px);
    }
    100%{
      opacity: 1;
      transform: translateY(0);
    }
  }
  /*动画-end*/
}

</style>