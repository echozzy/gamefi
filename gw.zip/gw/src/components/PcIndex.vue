<template>
  <div class="pc-index">
    <page-section @srollY="srolls">
      <section class="section">
        <div class="banner-con">
          <div class="banner-img">
            <img src="../assets/home/banner.png" alt="" />
          </div>
          <div class="banner-mask">
            <div class="download-con flex-fc">
<!--              <div class="download-top">-->
<!--                <img src="../assets/home/banner-logo.svg" alt="" />-->
<!--              </div>-->
              <div class="download-bottom flex">
                <div class="app-store">
                  <img src="../assets/home/app-store.png" alt="" />
                </div>
                <div class="google-play">
                  <img src="../assets/home/google-play.png" alt="" />
                </div>
              </div>
            </div>
            <div class="banner-down">
              <img src="../assets/home/banner-down.png" alt="" />
            </div>
          </div>
        </div>
      </section>
      <!-- <section class="section">
        <div class="section-item video-con flex-fc flex-ac">
          <div class="title">
            <img
              class="toptext"
              src="../assets/home/video-toptext.png"
              alt=""
            />
          </div>
          <div class="item-video" @click="play_video">
            <div class="video-bg">
              <img src="../assets/home/video-bg.png" alt="" />
            </div>
            <div class="video-play-con">
              <video
                class="video-play"
                poster="../assets/home/video-img.png"
                ref="video_play"
              >
                <source src="../assets/home/video-test.mp4" type="video/mp4" />
              </video>
              <div class="play-btn-con">
                <div v-show="isplay" class="play-btn"><img src="../assets/home/play_btn.png" alt=""></div>
              </div>
            </div>
          </div>
        </div>
      </section> -->
      <section class="section">
        <div class="section-item play-con flex-fc flex-ac">
          <div class="title">
            <p class="title-bg">PLAY THE GAME</p>
            <p class="title-top">GAME PLAY</p>
          </div>
          <div :class="rolls.value == -100 ? 'item-play fadeInRight animated go' : 'item-play fadeInRight animated'">
            <swiper
              :modules="modules"
              :loop="true"
              @swiper="onSwiper"
              @slideChange="onSlideChange"
            >
              <swiper-slide>
                <div class="game-play-img">
                    <div class="img-bg-left">
                    <img src="../assets/home/game-play-img.png" alt="" />
                    </div>
                    <div class="img-bg-right">
                      <div class="bg-right-title"><img src="../assets/home/title-top1.png"></div>
                      <div class="bg-right-icon"><img src="../assets/home/play_wf1.png"></div>
                      <div class="bg-right-nav">Star Collector</div>
                      <div class="bg-right-cont">
                        <p>Star Battle is the main 3V3 battle mode of Nova Battles. It is a desperate battle around the battle for Stars.</p>

                        <p> Be the first to collect more than ten Stars and maintain the advantage until the countdown ends to win.</p>
                      </div>
                    </div>
                </div>
              </swiper-slide>
              <swiper-slide>
                <div class="game-play-img">
                  <div class="img-bg-left">
                    <img src="../assets/home/game-play-img.png" alt="" />
                  </div>
                  <div class="img-bg-right">
                    <div class="bg-right-title"><img src="../assets/home/title-top1.png"></div>
                    <div class="bg-right-icon"><img src="../assets/home/play_wf2.png"></div>
                    <div class="bg-right-nav">Bounty Star</div>
                    <div class="bg-right-cont">Bounty Star’s main 3V3 battle mode, with the primary goal of killing enemies to snatch bounty stars.
                      <br/>
                      Within 3 minutes of the game, the side with more points on the scoring board wins, and the same score is a tie.</div>
                  </div>
                </div>
              </swiper-slide>
              <swiper-slide>
                <div class="game-play-img">
                  <div class="img-bg-left">
                    <img src="../assets/home/game-play-img.png" alt="" />
                  </div>
                  <div class="img-bg-right">
                    <div class="bg-right-title"><img src="../assets/home/title-top2.png"></div>
                    <div class="bg-right-icon"><img src="../assets/home/play_wf3.png"></div>
                    <div class="bg-right-nav">Battle Royale</div>
                    <div class="bg-right-cont">There are 10 players participating in each game of Battle Royale, which is divided into single-player and two-player modes.
                      <br/>
                      In a shrinking safe area, eliminate other players, the higher the survival ranking, the richer the rewards.</div>
                  </div>
                </div>
              </swiper-slide>
              <swiper-slide>
                <div class="game-play-img">
                  <div class="img-bg-left">
                    <img src="../assets/home/game-play-img.png" alt="" />
                  </div>
                  <div class="img-bg-right">
                    <div class="bg-right-title"><img src="../assets/home/title-top1.png"></div>
                    <div class="bg-right-icon"><img src="../assets/home/play_wf4.png"></div>
                    <div class="bg-right-nav">Football Shootout</div>
                    <div class="bg-right-cont">Football Shootout is a 3V3 match. Players who have not brought the ball can attack the enemy.
                      <br/>
                      Within 3 minutes of the game, the team that scored two goals first or the number of goals ahead wins the game.</div>
                  </div>
                </div>
              </swiper-slide>
              <swiper-slide>
                <div class="game-play-img">
                  <div class="img-bg-left">
                    <img src="../assets/home/game-play-img.png" alt="" />
                  </div>
                  <div class="img-bg-right">
                    <div class="bg-right-title"><img src="../assets/home/title-top1.png"></div>
                    <div class="bg-right-icon"><img src="../assets/home/play_wf5.png"></div>
                    <div class="bg-right-nav">Tower Defense</div>
                    <div class="bg-right-cont">Within 150 seconds of the game, the team that first destroys the opponent's tower wins. If no party successfully destroys the defensive tower, the victory will be judged based on the remaining HP of the defensive tower. If the remaining HP is the same, it will be a tie.</div>
                  </div>
                </div>
              </swiper-slide>
              <swiper-slide>
                <div class="game-play-img">
                  <div class="img-bg-left">
                    <img src="../assets/home/game-play-img.png" alt="" />
                  </div>
                  <div class="img-bg-right">
                    <div class="bg-right-title"><img src="../assets/home/title-top3.png"></div>
                    <div class="bg-right-icon"><img src="../assets/home/play_wf6.png"></div>
                    <div class="bg-right-nav">Hunting Game</div>
                    <div class="bg-right-cont">The hunting game is a 1V5 battle mode, and a random player will be the prey.
                      <br/>
                      Within 3 minutes of the game, 5 people attack the prey together, and defeating the prey counts as 5 people winning. On the contrary, the player who has not defeated the prey wins.</div>
                  </div>
                </div>
              </swiper-slide>
              <swiper-slide>
                <div class="game-play-img">
                  <div class="img-bg-left">
                    <img src="../assets/home/game-play-img.png" alt="" />
                  </div>
                  <div class="img-bg-right">
                    <div class="bg-right-title"><img src="../assets/home/title-top4.png"></div>
                    <div class="bg-right-icon"><img src="../assets/home/play_wf7.png"></div>
                    <div class="bg-right-nav">Runaway Monster</div>
                    <div class="bg-right-cont">Players need to work together to protect the city from monsters.
                      <br/>
                      If all buildings are destroyed or all heroes are defeated, the monster wins.</div>
                  </div>
                </div>
              </swiper-slide>
              <div class="pagination-con">
                <div class="pagination">
                  <span class="my-bullet" :class="nowActive==0?'my-bullet-active':''" @click="toSlide(1)"></span>
                  <span class="my-bullet" :class="nowActive==1?'my-bullet-active':''" @click="toSlide(2)"></span>
                  <span class="my-bullet" :class="nowActive==2?'my-bullet-active':''" @click="toSlide(3)"></span>
                  <span class="my-bullet" :class="nowActive==3?'my-bullet-active':''" @click="toSlide(4)"></span>
                  <span class="my-bullet" :class="nowActive==4?'my-bullet-active':''" @click="toSlide(5)"></span>
                  <span class="my-bullet" :class="nowActive==5?'my-bullet-active':''" @click="toSlide(6)"></span>
                  <span class="my-bullet" :class="nowActive==6?'my-bullet-active':''" @click="toSlide(7)"></span>
                </div>
              </div>
            </swiper>
            <!-- <div class="game-play-btn">
              <img src="../assets/home/game-play-btn.png" alt="" />
            </div> -->
          </div>
        </div>
      </section>
      <section class="section">
        <div class="section-item role-con flex-fc flex-ac">
          <div class="title">
            <p class="title-bg">PLAY THE GAME</p>
            <p class="title-top">HERO INTRODUCTION</p>
          </div>
          <div class="item-role-con">
            <swiper
              :modules="modules"
              :slides-per-view="5"
              @swiper="onTwoSwiper"
              @slideChange="onTwoSlideChange"
            >
              <swiper-slide v-for="item in lists" v-bind:key="item">
                <div class="role-item">
                  <div :class="rolls.value == -200 ? 'fadeInRight animated go' : 'fadeInRight animated'">
                  <img :src="item.imgUrl" alt="" />
                  </div>
                </div>
              </swiper-slide>
              <div class="pagination-con">
                <div class="pagination" style="justify-content: center">
                  <span class="my-bullet" :class="twoNowActive==0?'my-bullet-active':''" @click="twoToSlide(1)"></span>
                  <span class="my-bullet" :class="twoNowActive==1?'my-bullet-active':''" @click="twoToSlide(2)"></span>
                  <span class="my-bullet" :class="twoNowActive==2?'my-bullet-active':''" @click="twoToSlide(3)"></span>
                  <span class="my-bullet" :class="twoNowActive==3?'my-bullet-active':''" @click="twoToSlide(4)"></span>
                </div>
              </div>
            </swiper>
          </div>
        </div>
      </section>
      <section class="section">
        <div :class="rolls.value == -300 ? 'shiba-con fadeIn animatedtwo go' : 'shiba-con fadeIn animatedtwo'">
          <div class="shiba-txt-left flex-fc">
            <div class="txt-title">
              <div class="title-top">
                <img src="../assets/home/shiba-title2.png" alt="" />
              </div>
              <p class="title-bottom">Our History and ShibaInu</p>
            </div>
            <div class="txt-content">
              <div class="content-top">
                &nbsp;&nbsp;&nbsp;&nbsp;Our whole team are all investors of ShibaInu. Our team has a little bit of everything. Some are fresh crypto investors but avid gamers, others have been investing and trading since 2010. We realized why we invest and hold onto ShibaInu is truly because of the decentralized system it has adopted and the good initiatives it has done in the online and offline world.
              </div>
              <div class="content-mid"></div>
              <div class="content-bottom">
                &nbsp;&nbsp;&nbsp;&nbsp;We want the Shibarmy to grow and have incorporated an in-game system that BURNS Shiba tokens throughout the lifespan of this game. We are one with the people and we want the people to play, earn, and create together.
              </div>
            </div>
          </div>
          <div class="shiba-txt-right">
            <img src="../assets/home/shiba-right-img.png" alt="" />
          </div>
<!--          <div class="left-icon1">-->
<!--            <img src="../assets/home/shiba-left-icon1.svg" alt="" />-->
<!--          </div>-->
<!--          <div class="left-icon2">-->
<!--            <img src="../assets/home/shiba-left-icon2.png" alt="" />-->
<!--          </div>-->
<!--          <div class="right-icon1">-->
<!--            <img src="../assets/home/shiba-right-icon1.png" alt="" />-->
<!--          </div>-->
<!--          <div class="right-icon2">-->
<!--            <img src="../assets/home/shiba-right-icon2.png" alt="" />-->
<!--          </div>-->
        </div>
      </section>
      <section class="section">
        <div class="section-item links-con flex-fc flex-ac">
          <div class="title">
            <p class="title-bg">PLAY THE GAME</p>
            <p class="title-top">PARTNER</p>
          </div>
          <div class="item-links-con flex-fc">
            <div  :class="rolls.value == -400 ? 'links-item-con fadeInDownShort animatedtwo go' : 'links-item-con fadeInDownShort animatedtwo'">
              <div class="links-item">
                <img src="../assets/home/links-item1.png" alt="" />
              </div>
              <div class="links-item links-item-mid">
                <img src="../assets/home/links-item2.png" alt="" />
              </div>
              <div class="links-item">
                <img src="../assets/home/links-item3.png" alt="" />
              </div>
            </div>
            <div class="links-inp-con flex-fc">
              <div class="inp-title">ARE YOU READY TO START YOUR JOURNEY?</div>
              <div class="inp-con">
                <input
                  class="inp"
                  type="email"
                  placeholder="Enter Meail Address"
                />
                <div class="inp-btn" @click="subscribe">SUBMIT</div>
              </div>
            </div>
          </div>
        </div>
      </section>
      <section class="section">
        <div class="community-con flex-fc">
          <div class="community-logo flex">
            <img src="../assets/home/community-logo.png" alt="" />
          </div>

          <div class="community-download flex">
            <a class="community-download-app flex offceone">
              <img src="../assets/home/community-download-video.png" alt="" />
              <img class="download-hover-hide" src="../assets/home/community-download-hover.png" alt="" />
            </a>
            <a class="community-download-app flex">
              <img src="../assets/home/community-download-apple.png" alt="" />
              <img class="download-hover-hide" src="../assets/home/community-download-hover.png" alt="" />
            </a>
            <a class="community-download-app flex offcetwo">
              <img src="../assets/home/community-download-android.png" alt="" />
              <img class="download-hover-hide" src="../assets/home/community-download-hover.png" alt="" />
            </a>
            <a class="community-download-app flex offceone">
            </a>
          </div>

          <div class="community-item-con flex">
            <div class="community-icon">
              <a class="icon-sty iconimga" href="https://twitter.com/NoVaBattles" target="_blank">
              </a>
            </div>
            <div class="community-icon">
              <a class="icon-sty iconimgb" href="https://discord.io/NoVaBattles" target="_blank">
              </a>
            </div>
            <div class="community-icon">
              <a class="icon-sty iconimgc" href="https://www.instagram.com/nova.battles/" target="_blank">
              </a>
            </div>
            <div class="community-icon">
              <a class="icon-sty iconimgd" href="https://www.facebook.com/NoVaBattles" target="_blank">
              </a>
            </div>
            <div class="community-icon">
              <a class="icon-sty iconimge" href="https://www.reddit.com/r/NoVaBattles" target="_blank">
              </a>
            </div>
            <div class="community-icon">
              <a class="icon-sty iconimgf" href="https://t.me/NoVaBattles" target="_blank">
              </a>
            </div>
            <div class="community-icon">
              <a class="icon-sty iconimgg" href="https://novabattles.medium.com" target="_blank">
              </a>
            </div>
          </div>
          <div class="community-bottom-menus flex">
            <div class="menus-nav">
              <div class="menus-nav-icon flex">
                <img src="../assets/home/community-nav-icon.png" alt="" />
              </div>

              <a href="https://wp.novabattles.com/" target="_blank">
              <p class="menus-nav-txt">WHITEPAPER</p>
              </a>
            </div>
            <div class="menus-nav">
              <div class="menus-nav-icon flex">
                <img src="../assets/home/community-nav-icon.png" alt="" />
              </div>
              <a href="javascript:void(0)">
              <p class="menus-nav-txt">CONTACT US</p>
              </a>
            </div>
            <div class="menus-nav">
              <div class="menus-nav-icon flex">
                <img src="../assets/home/community-nav-icon.png" alt="" />
              </div>
              <a href="https://wp.novabattles.com/faqs/terms-of-use" target="_blank">
              <p class="menus-nav-txt">Terms Of Use</p>
              </a>
            </div>
            <div class="menus-nav">
              <div class="menus-nav-icon flex">
                <img src="../assets/home/community-nav-icon.png" alt="" />
              </div>
              <a href="https://wp.novabattles.com/faqs/privacy-policy" target="_blank">
              <p class="menus-nav-txt">Privacy Policy</p>
              </a>
            </div>
          </div>
          <div class="community-copyright">
            <p>ESLA TECHNOLOGY PTE.LTD. © 2021, All rights reserved</p>
          </div>
        </div>
      </section>
    </page-section>
  </div>
</template>

<script>
import {onMounted, ref ,reactive} from "vue";
import PageSection from "./PageSection.vue";
// import Swiper core and required modules
import { Navigation, Pagination, Autoplay } from "swiper";
// Import Swiper Vue.js components
import { Swiper, SwiperSlide } from "swiper/vue/swiper-vue";
// Import Swiper styles
import "swiper/swiper.min.css";
export default {
  components: {
    PageSection,
    Swiper,
    SwiperSlide,
  },
  name: "PcIndex",
  data(){
    return{
      lists:[
        { id:1,imgUrl:require('../assets/home/role1.png')},
        { id:2,imgUrl:require('../assets/home/role2.png')},
        { id:3,imgUrl:require('../assets/home/role3.png')},
        { id:4,imgUrl:require('../assets/home/role4.png')},
        { id:5,imgUrl:require('../assets/home/role1.png')},
        { id:6,imgUrl:require('../assets/home/role2.png')},
        { id:7,imgUrl:require('../assets/home/role3.png')},
        { id:8,imgUrl:require('../assets/home/role4.png')},
        { id:9,imgUrl:require('../assets/home/role1.png')},
        { id:10,imgUrl:require('../assets/home/role2.png')},
        { id:11,imgUrl:require('../assets/home/role3.png')},
        { id:12,imgUrl:require('../assets/home/role4.png')},
        { id:13,imgUrl:require('../assets/home/role1.png')},
        { id:14,imgUrl:require('../assets/home/role2.png')},
        { id:15,imgUrl:require('../assets/home/role3.png')},
        { id:16,imgUrl:require('../assets/home/role4.png')},
        { id:17,imgUrl:require('../assets/home/role1.png')},
      ]
    }
  },
  setup() {
    //屏幕滚动参数
    onMounted(() => {
      window.addEventListener("mousewheel", dataroll, true)
    })
    const isScroll = ref(false);
    const rolls = reactive({
      value: 0,
    });
    function dataroll() {
      if (isScroll.value) {
        return;
      }
      isScroll.value = true;
      setTimeout(() => {
        isScroll.value = false;
      }, 500);
      rolls.value = JSON.parse(sessionStorage.getItem('dataroll'));
    }

    //视频播放
    const isplay = ref(true);
    const video_play = ref(null);

    function play_video() {
      if (isplay.value) {
        video_play.value.play();
        isplay.value = false;
      } else {
        video_play.value.pause();
        isplay.value = true;
      }
    }

    let firstSwiper = null
    const nowActive = ref(0)
    const onSwiper = (swiper) => {
      firstSwiper = swiper
    };
    const onSlideChange = (firstSwiper) => {
      nowActive.value = firstSwiper.realIndex
    };
    function toSlide(index) {
      let all_num = firstSwiper.slides.length-3
      if(index==1&&firstSwiper.realIndex==all_num){
        firstSwiper.slideNext()
        nowActive.value = firstSwiper.realIndex
        return
      }
      if(index==6&&firstSwiper.realIndex==0){
        firstSwiper.slidePrev()
        nowActive.value = firstSwiper.realIndex
        return
      }
      firstSwiper.slideTo(index)
      nowActive.value = firstSwiper.realIndex
    }

    let twoSwiper = null
    const twoNowActive = ref(0)
    const onTwoSwiper = (swiper) => {
      twoSwiper = swiper
    };
    const onTwoSlideChange = (twoSwiper) => {
      if(twoSwiper.activeIndex<4){
        twoNowActive.value = 0
      }
      if(twoSwiper.activeIndex>=4&&twoSwiper.activeIndex<8){
        twoNowActive.value = 1
      }
      if(twoSwiper.activeIndex>=8&&twoSwiper.activeIndex<12){
        twoNowActive.value = 2
      }
      if(twoSwiper.activeIndex>=12&&twoSwiper.activeIndex<16){
        twoNowActive.value = 3
      }
    };
    function twoToSlide(index) {
      if(index==1){
        twoSwiper.slideTo(0)
        twoNowActive.value = 0
      }
      if(index==2){
        twoSwiper.slideTo(4)
        twoNowActive.value = 1
      }
      if(index==3){
        twoSwiper.slideTo(8)
        twoNowActive.value = 2
      }
      if(index==4){
        twoSwiper.slideTo(12)
        twoNowActive.value = 3
      }
    }
    return {
      rolls,
      isplay,
      video_play,
      play_video,
      modules: [Navigation, Autoplay, Pagination],
      onSwiper,onSlideChange,toSlide,firstSwiper,nowActive,
      twoNowActive,onTwoSwiper,onTwoSlideChange,twoToSlide
    };
  },
  methods:{
    srolls:function (data) {
      this.rolls.value = data;
    }
  }
};
</script>

<style lang="less">
  @media screen and (min-width: 857px){
    @font-face {
      font-family: NovaBattle;
      src: url("../assets/font/novabattlePro.ttf");
    }
    .pc-index {
      .section-item {
        width: 100%;
        justify-content: center;
      }
      .banner-con {
        position: relative;
        width: 100%;
        height: 100vh;
        padding: 15px 10px 10px 10px;
        box-sizing: border-box;
        .banner-img {
          width: 100%;
          height: 100%;
          img {
            height: 100%;
          }
        }
        .banner-mask {
          position: absolute;
          top: 0;
          width: 100%;
          height: 100%;
          display: flex;
          justify-content: center;
          .download-con {
            margin-top: 4rem;
            .download-bottom {
              margin-top: 91px;
              display: none;
              justify-content: space-between;
            }
          }
          .banner-down {
            display: flex;
            position: absolute;
            left: 50%;
            bottom: 15px;
            transform: translate(-50%, -50%);
            animation: banner-down-opacity-change 2s ease-in-out infinite;
            -webkit-animation: banner-down-opacity-change 2s ease-in-out infinite;
            -moz-animation: banner-down-opacity-change 2s ease-in-out infinite;
            -o-animation: banner-down-opacity-change 2s ease-in-out infinite;
          }
          @keyframes banner-down-opacity-change {
            0% {
              opacity: 0.2
            }
            50%{
              opacity:1
            }
            100% {
              opacity: 0.2
            }
          }
        }
      }
      .video-con {
        .title {
          position: relative;
          top: 47px;
          .toptext {
            width: 10rem;
            height: 1.1rem;
          }
          p {
            color: rgba(216, 216, 216, 0);
            font-size: 1.25rem;
            -webkit-text-stroke: 2px rgba(102, 154, 196, 1);
            text-align: center;
            font-family: NovaBattle;
            opacity: 0.5;
            letter-spacing: 0.09rem;
          }
        }
        .item-video {
          width: 11.39rem;
          height: 5.67rem;
          position: relative;
          display: flex;
          justify-content: center;
          .video-bg {
            width: 100%;
            position: absolute;
            z-index: 2;
            img {
              height: 100%;
            }
          }
          .video-play-con {
            width: 10.5rem;
            height: 5.1rem;
            display: flex;
            justify-content: center;
            align-items: center;
            position: relative;
            transform: perspective(50px) rotateX(0.5deg);
            .video-play {
              width: 99%;
              height: 99%;
              object-fit: cover;
            }
            .play-btn-con {
              width: 99%;
              height: 99%;
              position: absolute;
              display: flex;
              justify-content: center;
              align-items: center;
              cursor: pointer;
            }
          }
        }
      }
      .pagination-con {
        display: flex;
        align-items: center;
        position: relative;
        top: -0.15rem;
        margin-left: 0.6rem;
        z-index: 2;
        .pagination {
          display: flex;
          width: 100%;
          margin: 0.2rem 0.2rem;
          .my-bullet {
            background: url(../assets/home/swiper-slide.png) no-repeat;
            background-size: 100% 100%;
            width: 12%;
            height: 0.11rem;
            cursor: pointer;
          }
          .my-bullet-active {
            background: url(../assets/home/swiper-slide-active.png) no-repeat;
            background-size: 100% 100%;
            width: 12%;
            height: 0.11rem;
          }
        }
        .swiper-button-prev,
        .swiper-button-next {
          display: flex;
        }
      }
      .play-con {
        .title {
          margin-top: 0.62rem;
          position: relative;
          display: flex;
          justify-content: center;
          align-items: center;
          .title-bg {
            position: relative;
            z-index: 1;
            color: rgba(216, 216, 216, 0);
            font-size: 1.2rem;
            letter-spacing: 2px;
            opacity: 0.75;
            -webkit-text-stroke: 2px rgba(113, 153, 192, 0.25);
          }
          .title-top {
            position: absolute;
            font-size: 0.45rem;
            font-weight: 800;
            color: #8ec4f9;
            letter-spacing: 0.1rem;
            text-shadow: 0px 0px 40px #8ec4f9;
          }
        }
        .item-play {
          width: 50%;
          position: relative;
          .swiper-pointer-events{
            border-radius: 0.25rem;
          }
          .game-play-btn {
            position: absolute;
            bottom: 0.2rem;
            width: 2.15rem;
            right: 1.72rem;
            transform: translateY(15%);
            z-index: 1;
            display: flex;
          }
          .game-play-img{
            display: flex;
            .img-bg-left{
              width: 100%;
            }
            .img-bg-right{
              width: 60%;
              position: absolute;
              margin-left: 45%;
              .bg-right-title{
                position: absolute;
                width: 80%;
                margin-top: 22%;
                img{
                  position: absolute;
                }
              }
              .bg-right-icon{
                position: absolute;
                width: 20%;
                margin-left: 58%;
                margin-top: 15%;
                img{
                  position: absolute;
                }
              }
              .bg-right-nav{
                position: absolute;
                color: #7199c0;
                font-size: 0.3rem;
                letter-spacing: 0.05rem;
                text-align: left;
                text-shadow: 0px 0px 0.1rem #7199c1;
                margin-top:30%;
                margin-left: 12%;
              }
              .bg-right-cont{
                width: 60%;
                color: #ffffff;
                font-size: 0.15rem;
                line-height: 0.22rem;
                text-align: left;
                overflow: hidden;
                position: absolute;
                margin-top:42%;
                margin-left: 12%;
              }
            }

          }
        }
      }
      .role-con {
        .title {
          margin-top: 0.62rem;
          position: relative;
          display: flex;
          justify-content: center;
          align-items: center;

          .title-bg {
            position: relative;
            z-index: 1;
            color: rgba(216, 216, 216, 0);
            font-size: 1.2rem;
            font-family: NovaBattle;
            letter-spacing: 2px;
            opacity: 0.75;
            -webkit-text-stroke: 2px rgba(113, 153, 192, 0.25);
          }

          .title-top {
            font-family: NovaBattle;
            position: absolute;
            font-size: 0.45rem;
            font-weight: 800;
            color: #8ec4f9;
            letter-spacing: 0.1rem;
            text-shadow: 0px 0px 40px #8ec4f9;
          }
        }

        .item-role-con {
          width: 10rem;
          .role-item {
            // width: 284px;
            // height: 466px;
            img {
              height: 100%;
            }
          }

          .pagination-con {
            display: flex;
            justify-content: center;
            margin-top: 0.5rem;
            margin-left: 0;
          }
        }
      }
      .shiba-con {
        width: 12.7rem;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        .shiba-txt-left {
          width: 5.26rem;
          // margin-right: 55px;
          .txt-title {
            position: relative;
            margin-bottom: 0.46rem;
            .title-top {
              display: flex;
            }
            .title-bottom {
              position: relative;
              color: rgba(255, 164, 9, 1);
              font-size: 0.28rem;
              text-shadow: 0px 0px 0.2rem #ffa409;
              margin-top: -0.1rem;
              // font-family: PingFangSC-Semibold;
              font-family: NovaBattle;
              white-space: nowrap;
              letter-spacing: 2.5px;
              line-height: 0.33rem;
              text-align: left;
            }
          }
          .txt-content {
            .content-top {
              font-size: 0.16rem;
              // font-family: BlenderPro-Heavy, BlenderPro;
              font-family: NovaBattle;
              font-weight: 800;
              color: #ffffff;
              line-height: 0.25rem;
              margin-bottom: 0.42rem;
            }
            .content-mid {
              width: 1.67rem;
              height: 2px;
              background: #ffa409;
              margin-bottom: 0.42rem;
            }
            .content-bottom {
              font-size: 0.16rem;
              // font-family: BlenderPro-Heavy, BlenderPro;
              font-family: NovaBattle;
              opacity: 0.5;
              font-weight: 800;
              color: #ffffff;
              line-height: 0.22rem;
            }
          }
        }
        .shiba-txt-right {
          width: 3rem;
          display: flex;
          align-items: center;
        }
        .left-icon1,
        .left-icon2,
        .right-icon1,
        .right-icon2 {
          position: absolute;
          display: flex;
        }
        .left-icon1 {
          top: 2.75rem;
          left: 1.5rem;
          box-sizing: border-box;
          padding-top: 0.2rem;
        }
        .left-icon2 {
          left: 0;
          bottom: 2.1rem;
          -webkit-animation: left-icon2 5s ease-in-out alternate infinite;
          animation: left-icon2 5s ease-in-out alternate infinite;
          animation-delay: 3s;
        }
        @-webkit-keyframes left-icon2 {
          0%,
          100% {
            bottom: 2.2rem;
          }
          50% {
            bottom: 1.8rem;
          }
        }
        @keyframes left-icon2 {
          0%,
          100% {
            bottom: 2.2rem;
          }
          50% {
            bottom: 1.8rem;
          }
        }
        .right-icon1 {
          right: 0;
          top: 1.4rem;
          -webkit-animation: right-icon1 5s ease-in-out alternate infinite;
          animation: right-icon1 5s ease-in-out alternate infinite;
          animation-delay: 1s;
        }
        @-webkit-keyframes right-icon1 {
          0%,
          100% {
            top: 1.6rem;
          }
          50% {
            top: 1rem;
          }
        }
        @keyframes right-icon1 {
          0%,
          100% {
            top: 1.6rem;
          }
          50% {
            top: 1rem;
          }
        }
        .right-icon2 {
          right: 0;
          bottom: 1.1rem;
          transform: translateX(50%);
          -webkit-animation: right-icon2 4s ease-in-out alternate infinite;
          animation: right-icon2 4s ease-in-out alternate infinite;
          animation-delay: 4s;
        }
        @-webkit-keyframes right-icon2 {
          0%,
          100% {
            bottom: 1.2rem;
          }
          50% {
            bottom: 0.9rem;
          }
        }
        @keyframes right-icon2 {
          0%,
          100% {
            bottom: 1.2rem;
          }
          50% {
            bottom: 0.9rem;
          }
        }
      }
      .links-con {
        .title {
          margin-top: 0.62rem;
          position: relative;
          display: flex;
          justify-content: center;
          align-items: center;
          .title-bg {
            position: relative;
            z-index: 1;
            color: rgba(216, 216, 216, 0);
            font-size: 1.2rem;
            font-family: NovaBattle;
            letter-spacing: 2px;
            opacity: 0.75;
            -webkit-text-stroke: 2px rgba(113, 153, 192, 0.25);
          }
          .title-top {
            font-family: NovaBattle;
            position: absolute;
            font-size: 0.45rem;
            font-weight: 800;
            color: #8ec4f9;
            letter-spacing: 0.1rem;
            text-shadow: 0px 0px 40px #8ec4f9;
          }
        }
        .item-links-con {
          margin-top: 1.2rem;
          .links-item-con {
            display: flex;
            justify-content: center;
            .links-item {
              width: 2.5rem;
            }
            .links-item-mid {
              margin: 0 0.55rem;
            }
          }
          .links-inp-con {
            background: url(../assets/home/links-inp-con-bg.png) no-repeat;
            background-size: 100% 100%;
            width: 10rem;
            height: 1.65rem;
            margin-top: 1.5rem;
            .inp-title {
              font-size: 0.24rem;
              // font-family: BlenderPro-Heavy, BlenderPro;
              font-family: NovaBattle;
              font-weight: 800;
              color: #6f99be;
              line-height: 0.34rem;
              display: flex;
              justify-content: center;
              margin-top: 0.25rem;
            }
            .inp-con {
              margin-top: 0.25rem;
              width: 100%;
              display: flex;
              justify-content: center;
              .inp {
                width: 5.64rem;
                height: 0.45rem;
                font-family: NovaBattle;
                font-size: 0.18rem;
              }
              input {
                width: 100%;
                height: 100%;
                outline-style: none;
                border: 1px solid #43576fcc;
                border-right: 0;
                border-radius: 0.04rem;
                padding: 0.1rem 0.16rem;
                font-size: 0.3rem;
                color: #131313;
                background: #ffffff;
              }
              input:focus {
                border-color: #66afe9;
                outline: 0;
                -webkit-box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075),
                0 0 8px rgba(102, 175, 233, 0.6);
                box-shadow: inset 0 1px 1px rgba(0, 0, 0, 0.075),
                0 0 8px rgba(102, 175, 233, 0.6);
              }
              .inp-btn {
                width: 1.64rem;
                height: 0.45rem;
                margin-left: -2px;
                background: #6f99be;
                font-size: 0.18rem;
                // font-family: BlenderPro-Heavy, BlenderPro;
                font-family: NovaBattle;
                letter-spacing: 2px;
                font-weight: 800;
                color: #ffffff;
                display: flex;
                justify-content: center;
                align-items: center;
                border-radius: 0 0.04rem 0.04rem 0;
                &:hover {
                  background: #8ac0ef;
                }
              }
            }
          }
        }
      }
      .community-con {
        align-items: center;
        justify-content: center;
        .community-logo {
          width: 750px;
          justify-content: center;
          margin: 90px auto;
          img{
            width: 570px;
            height: 210px;
          }
        }
        .community-download {
          width: 4.25rem;
          justify-content: space-around;
          position: relative;
          margin-top: 0.1rem;
          .community-download-app{
            height: 0.65rem;
            margin: 0 0.08rem;
            position: absolute;
            img{
              width: 1.88rem;
              height: 0.65rem;
            }
            .download-hover-hide{
              position: absolute;
              display: none;
            }
          }
          .community-download-app:hover{
            .download-hover-hide{
              display: block;
            }
          }
          .offceone{
            margin-right: 4.5rem;
          }
          .offcetwo{
            margin-left: 4.5rem;
          }
        }
        .community-item-con {
          width: 5rem;
          justify-content: center;
          margin-top: 1.6rem;
          .community-icon {
            display: flex;
            margin-left: 0.1rem;
            margin-right: 0.1rem;
            .icon-sty{
              display: block;
              width: 0.59rem;
              height: 0.59rem;
            }
            .iconimga{
              background: url("../assets/home/community-icon1.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimga:hover{
              background: url("../assets/home/community-icon1-hover.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimgb{
              background: url("../assets/home/community-icon2.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimgb:hover{
              background: url("../assets/home/community-icon2_hover.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimgc{
              background: url("../assets/home/community-icon3.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimgc:hover{
              background: url("../assets/home/community-icon3_hover.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimgd{
              background: url("../assets/home/community-icon4.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimgd:hover{
              background: url("../assets/home/community-icon4_hover.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimge{
              background: url("../assets/home/community-icon5.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimge:hover{
              background: url("../assets/home/community-icon5_hover.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimgf{
              background: url("../assets/home/community-icon6.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimgf:hover{
              background: url("../assets/home/community-icon6_hover.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimgg{
              background: url("../assets/home/community-icon7.png") no-repeat;
              background-size: 100% 100%;
            }
            .iconimgg:hover{
              background: url("../assets/home/community-icon7_hover.png") no-repeat;
              background-size: 100% 100%;
            }
          }
        }
        .community-copyright {
          margin-top: 0.4rem;
          p {
            text-align: center;
            font-size: 0.14rem;
            font-family: NovaBattle;
            // font-family: BlenderPro-Heavy, BlenderPro;
            font-weight: 800;
            color: rgba(151, 151, 151, 1);
            line-height: 0.29rem;
          }
        }
        .community-bottom-menus {
          margin-top: 0.95rem;
          width: 6.83rem;
          justify-content: space-between;
          .menus-nav {
            display: flex;
            align-items: center;
            .menus-nav-icon {
              margin-right: 0.13rem;
              width: 0.1rem;
              height: 0.15rem;
            }
            .menus-nav-txt {
              font-family: NovaBattle;
              font-size: 0.18rem;
              font-weight: 800;
              color: #6d9bbf;
            }
            .menus-nav-txt:hover{
              color: #fff;
            }
          }
        }
      }
    }

    /*动画-start*/
    .fadeInRight.go {
      -webkit-animation-name: fadeInRight;
      animation-name: fadeInRight;
    }
    .fadeInRight {
      opacity: 0;
      -webkit-transform: translateX(3rem);
      transform: translateX(3rem);
    }
    .fadeIn.go{
      -webkit-animation-name: fadeIn;
      animation-name: fadeIn;
    }
    .fadeIn {
      opacity: 0;
    }
    .fadeInDownShort.go{
      -webkit-animation-name: fadeInDownShort;
      animation-name: fadeInDownShort;
    }
    .fadeInDownShort{
      opacity: 0;
      -webkit-transform: translateY(-0.3rem);
      transform: translateY(-0.3rem);
    }
    .animated{
      -webkit-animation-duration:0.7s;
      animation-duration: 0.7s;
      -webkit-animation-fill-mode: both;
      animation-fill-mode: both;
    }
    .animatedtwo{
      -webkit-animation-duration:0.7s;
      animation-duration: 2s;
      -webkit-animation-fill-mode: both;
      animation-fill-mode: both;
    }
    @keyframes fadeInRight {
      0%{
        opacity: 0;
        transform: translateX(3rem);
      }
      60%{
        opacity: 0.6;
      }
      100%{
        opacity: 1;
        transform: translateX(0);
      }
    }
    @keyframes fadeIn{
      0%{
        opacity: 0;
      }
      10%{
        opacity: 0.1;
      }
      20%{
        opacity: 0.2;
      }
      100%{
        opacity: 1;
        display: block;
      }
    }
    @keyframes fadeInDownShort{
      0%{
        opacity: 0;
        transform: translateY(-0.3rem);
      }
      100%{
        opacity: 1;
        transform: translateY(0);
      }
    }
    /*动画-end*/
  }


</style>