<template>
  <!--pc端-->
  <div class="view-container">
    <div class="top-breathing-con">
      <div class="top-breathing" :class="rolls.value != 0 ? 'top-breathing' : 'top-breathing top-hide'">
        <div class="bg-left breathing">
          <div class="top">
            <div class="background-left-top"><img src="../assets/home/bg/background_left_top.png" alt=""></div>
          </div>
          <div class="bottom flex">
            <div class="background-left-line"><img src="../assets/home/bg/background_left_line.png" alt=""></div>
            <div class="item2 flex-fc">
              <div class="background-left-num"><img src="../assets/home/bg/background_left_num.png" alt=""></div>
              <div class="background-left-num2"><img src="../assets/home/bg/background_left_num.png" alt=""></div>
              <div class="background-left-midbox">
                <img src="../assets/home/bg/background_left_midbox.png" alt="" style="">
                <img class="left-midbox-ling" src="../assets/home/bg/backgroun-ling.png" alt="">
              </div>
              <div class="background-left-role">
                <img src="../assets/home/bg/background_bottom_yuan.png" alt="">
              </div>
            </div>
            <div class="item1 flex-fc">
              <div class="background-left-x"><img src="../assets/home/bg/background_left_x.png" alt=""></div>
              <div class="background-left-rule"><img src="../assets/home/bg/background_left_rule.png" alt=""></div>
            </div>
          </div>
        </div>
        <div class="mid"></div>
        <div class="bg-right breathing">
          <div class="top">
            <div class="background-right-top"><img src="../assets/home/bg/background_right_top.png" alt=""></div>
          </div>
          <div class="bottom-right flex">
            <div class="background-right-line"><img src="../assets/home/bg/background_right_line.png" alt=""></div>
            <div class="item2 flex-fc">
              <div class="background-right-num"><img src="../assets/home/bg/background_right_num.png" alt=""></div>
              <div class="background-right-num2"><img src="../assets/home/bg/background_right_num.png" alt=""></div>
              <div class="background-right-midbox">
                <div class="right-midbox-pf">
                  <div :class="rolls.value == 0 ? 'right-midbox-a active-go' : 'right-midbox-a'" @click="changes(0)" ref="ceshi"></div>
                  <div :class="rolls.value == -100 ? 'right-midbox-a active-go' : 'right-midbox-a'" @click="changes(-100)" ref="ceshi"></div>
                  <div :class="rolls.value == -200 ? 'right-midbox-a active-go' : 'right-midbox-a'" @click="changes(-200)"></div>
                  <div :class="rolls.value == -300 ? 'right-midbox-a active-go' : 'right-midbox-a'" @click="changes(-300)"></div>
                  <div :class="rolls.value == -400 ? 'right-midbox-a active-go' : 'right-midbox-a'" @click="changes(-400)"></div>
                  <div :class="rolls.value == -500 ? 'right-midbox-a active-go' : 'right-midbox-a'" @click="changes(-500)"></div>
                </div>
                <div class="right-midbox-role">
                  <img  src="../assets/home/bg/background_right_midbox.png" alt="" style="width: 164px">
                  <img class="right-midbox-ling" src="../assets/home/bg/backgroun-ling.png" alt="" style="margin-left: -23px;">
                </div>
              </div>
              <div class="background-right-role"></div>
              <div class="background-right-bottom">
                <a  class="right-bottom-ta" target="_blank" href="https://discord.io/NoVaBattles">
                  <img src="../assets/home/background-bom1.png" alt="">
                  <span>COMMUNITY</span>
                </a>
                <a class="right-bottom-tb" target="_blank" href="https://twitter.com/NoVaBattles"><img src="../assets/home/background-bom2.png" alt=""></a>
                <a class="right-bottom-tc" target="_blank" href="https://t.me/NoVaBattles"><img src="../assets/home/background-bom3.png" alt=""></a>
                <a class="right-bottom-td" target="_blank" href="https://www.instagram.com/nova.battles"><img src="../assets/home/background-bom4.png" alt=""></a>
              </div>
            </div>
            <div class="item1 flex-fc">
              <div class="background-right-x"><img src="../assets/home/bg/background_right_x.png" alt=""></div>
              <div class="background-right-rule"><img src="../assets/home/bg/background_right_rule.png" alt=""></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div
      class="section-container"
      ref="sectiondom"
      :style="
        `transform: translateY(` +
        translateY +
        `vh); transition-duration: 500ms;`
      "
    >
      <slot></slot>
    </div>
  </div>
</template>

<script>
import { ref,onMounted,reactive } from "vue";
export default {
  name: "PageSection",
  setup(){
    const sectiondom = ref(null)
    onMounted(() => {
      window.addEventListener("mousewheel", handleScroll, true);
      maxHeight.value = -(sectiondom.value.children.length-1)*100
    })
    const translateY = ref(0)
    const isScroll = ref(false)
    const maxHeight = ref(0)
    const rolls = reactive({
      value: 0,
    });

    function handleScroll(e) {
      if (isScroll.value) {
        return;
      }
      isScroll.value = true;
      setTimeout(() => {
        isScroll.value = false;
      }, 500);
      // 向哪个方向滚动
      if (e.deltaY > 0) {
        //   向下滚动
        if(translateY.value <= maxHeight.value){
          return;
        }
        translateY.value -= 100;
      } else {
        // 向上滚动
        if (translateY.value >= 0) {
          return;
        }
        translateY.value += 100;
      }
      sessionStorage.setItem('dataroll', JSON.stringify(translateY.value));
      rolls.value = translateY.value
    }
    return {
      handleScroll,sectiondom,translateY,rolls
    }
  },
  methods:{
    changes(e){
      //直接跳转
      this.translateY = e;
      //动画参数判断
      this.rolls.value =e;
      //动画参数传值给父页面
      this.$emit("srollY",e);
    }
  }

};
</script>

<style lang="less">
  @media screen and (min-width: 857px){
    .top-hide{
      display: none!important;
    }
    .view-container {
      width: 100%;
      height: 100vh;
      overflow-y: hidden;
      background: url(../assets/home/bg.png) no-repeat;
      background-size: 99% 97%;
      background-attachment:fixed;
      background-position:center;
      position: relative;
      .section-container {
        width: 100%;
        overflow: hidden;
        position: absolute;
        z-index: 1;
        .section {
          width: 100%;
          height: 100vh;
          display: flex;
          justify-content: center;
        }
      }
      .top-breathing-con{
        position: absolute;
        left: 0;
        width: 100%;
        height: 100%;
        display: flex;
        justify-content: center;
        align-items: center;
        overflow: hidden;
        .top-breathing{
          width: 100%;
          display: flex;
          align-items: center;
          position: relative;
          margin-bottom:0.23rem;
          .bg-left{
            width: 28%;
            z-index: 3;
            margin-left: 0.3rem;
            height: 100%;
          }
          .mid{
            width: 100%;
          }
          .bg-right{
            width: 28%;
            z-index: 3;
            margin-right: 0.3rem;
            height: 100%;
          }
          .breathing{
            display: flex;
            flex-direction: column;
            position: relative;
            .top{
              display: flex;
              justify-content: center;
              .background-left-top,.background-right-top{
                width: 1.81rem;
                display: flex;
                animation: opacity-change 10s ease-in-out 1s infinite;
                -webkit-animation: opacity-change 10s ease-in-out 1s infinite;
                -moz-animation: opacity-change 10s ease-in-out 1s infinite;
                -o-animation: opacity-change 10s ease-in-out 1s infinite;
              }
              margin-bottom: 0.36rem;
            }
            .bottom,.bottom-right{
              justify-content: space-between;
              flex-direction: row-reverse;
              .background-left-line,.background-right-line{
                width: 0.1rem;
                height: 82vh;
                animation: opacity-change 10s ease-in-out 3s infinite;
                -webkit-animation: opacity-change 10s ease-in-out 3s infinite;
                -moz-animation: opacity-change 10s ease-in-out 3s infinite;
                -o-animation: opacity-change 10s ease-in-out 3s infinite;
                img{
                  height: 100%;
                }
              }
              .item1{
                margin-top: 0.2rem;
                .background-left-x,.background-right-x{
                  display: flex;
                  width: 0.31rem;
                  height: 0.73rem;
                  animation: opacity-change 10s ease-in-out 9s infinite;
                  -webkit-animation: opacity-change 10s ease-in-out 9s infinite;
                  -moz-animation: opacity-change 10s ease-in-out 9s infinite;
                  -o-animation: opacity-change 10s ease-in-out 9s infinite;
                }
                .background-left-rule,.background-right-rule{
                  display: flex;
                  margin-top: 1.3rem;
                  width: 0.52rem;
                  height: 3.28rem;
                  animation: opacity-change 10s ease-in-out 7s infinite;
                  -webkit-animation: opacity-change 10s ease-in-out 7s infinite;
                  -moz-animation: opacity-change 10s ease-in-out 7s infinite;
                  -o-animation: opacity-change 10s ease-in-out 7s infinite;
                }
              }
              .item2{
                .background-left-num,.background-left-num2,.background-right-num,.background-right-num2{
                  display: flex;
                  width: 0.96rem;
                  height: 0.33rem;
                  align-self: flex-end;
                }
                .background-left-num,.background-right-num{
                  margin-top: 0.8rem;
                  animation: opacity-change 10s ease-in-out 2s infinite;
                  -webkit-animation: opacity-change 10s ease-in-out 2s infinite;
                  -moz-animation: opacity-change 10s ease-in-out 2s infinite;
                  -o-animation: opacity-change 10s ease-in-out 2s infinite;
                }
                .background-left-num2,.background-right-num2{
                  margin-top: 0.8rem;
                  animation: opacity-change 10s ease-in-out 6s infinite;
                  -webkit-animation: opacity-change 10s ease-in-out 6s infinite;
                  -moz-animation: opacity-change 10s ease-in-out 6s infinite;
                  -o-animation: opacity-change 10s ease-in-out 6s infinite;
                }
                .background-left-midbox{
                  width: 1.64rem;
                  height: 1.62rem;
                  margin-top: 0.83rem;
                  display: flex;
                  flex-wrap: wrap;
                  animation: opacity-change 10s ease-in-out 4s infinite;
                  -webkit-animation: opacity-change 10s ease-in-out 4s infinite;
                  -moz-animation: opacity-change 10s ease-in-out 4s infinite;
                  -o-animation: opacity-change 10s ease-in-out 4s infinite;
                  .left-midbox-ling{
                    width: 0.43rem;
                    margin-left: 1.21rem;
                    margin-top: 0.35rem;
                  }
                }
                .background-right-midbox{
                  width: 1.64rem;
                  height: 1.2rem;
                  margin-top: 0.35rem;
                  display: flex;
                  animation: opacity-change 10s ease-in-out 4s infinite;
                  -webkit-animation: opacity-change 10s ease-in-out 4s infinite;
                  -moz-animation: opacity-change 10s ease-in-out 4s infinite;
                  -o-animation: opacity-change 10s ease-in-out 4s infinite;
                  .right-midbox-pf{

                  }
                  .right-midbox-role {
                    display: flex;
                    flex-wrap: wrap;
                    margin-top: 0.49rem;
                    margin-left: 0.15rem;
                    .right-midbox-ling {
                      width: 0.43rem;
                      margin-top: 0.35rem;
                    }
                  }
                  .right-midbox-a{
                    color: #494a6a;
                    background: url("../assets/home/right-list.png") no-repeat;
                    background-size: 100% 100%;
                    cursor: pointer;
                    margin-top: 0.15rem;
                    width: 0.09rem;
                    height: 0.18rem;
                    font-size: 0.13rem;
                    span{
                      margin-left: 35%;
                    }
                  }
                  .active-go{
                    background: url("../assets/home/right-list-hover.png") no-repeat;
                    background-size: 100% 100%;
                    color: #6C9EC5;
                  }
                }
                .background-left-role{
                  width: 1.41rem;
                  height: 1.3rem;
                  margin-top: 1.25rem;
                  animation: opacity-change 10s ease-in-out 8s infinite;
                  -webkit-animation: opacity-change 10s ease-in-out 8s infinite;
                  -moz-animation: opacity-change 10s ease-in-out 8s infinite;
                  -o-animation: opacity-change 10s ease-in-out 8s infinite;
                }
                .background-right-role{
                  width: 0.43rem;
                  height: 1.3rem;
                  animation: opacity-change 10s ease-in-out 8s infinite;
                  -webkit-animation: opacity-change 10s ease-in-out 8s infinite;
                  -moz-animation: opacity-change 10s ease-in-out 8s infinite;
                  -o-animation: opacity-change 10s ease-in-out 8s infinite;
                }
              }
            }
            .bottom-right{
              flex-direction: row;
              .item2{
                .background-left-num,.background-left-num2,.background-right-num,.background-right-num2{
                  display: flex;
                  width: 0.96rem;
                  height: 0.33rem;
                  align-self: flex-start;
                }
                .background-right-role{
                  align-self: flex-end;
                  margin-left: 0;
                  margin-top: 0.7rem;
                }
                .background-right-bottom{
                  position: relative;
                  width: 100%;
                  left: 1.5rem;
                  top: 0.68rem;
                  animation: opacity-change 10s ease-in-out 3s infinite;
                  -webkit-animation: opacity-change 10s ease-in-out 3s infinite;
                  -moz-animation: opacity-change 10s ease-in-out 3s infinite;
                  -o-animation: opacity-change 10s ease-in-out 3s infinite;
                  .right-bottom-ta{
                    display: block;
                    width: 0.95rem;
                    height: 0.95rem;
                    line-height: 0.3rem;
                    position: absolute;
                    left: -0.5rem;
                    text-align: center;
                    span{
                      display: block;
                      font-size: 0.12rem;
                      color: rgba(73, 74, 106, 1);
                    }
                  }
                  .right-bottom-tb{
                    display: block;
                    width:0.49rem;
                    height: 0.49rem;
                    position: absolute;
                    top: -0.3rem;
                    left: -1.3rem;
                  }
                  .right-bottom-tc{
                    display: block;
                    width:0.49rem;
                    height: 0.49rem;
                    position: absolute;
                    top: -1.1rem;
                    left: -0.9rem;
                  }
                  .right-bottom-td{
                    display: block;
                    width:0.49rem;
                    height: 0.49rem;
                    position: absolute;
                    top: -1.3rem;
                  }
                }
              }
            }
          }
        }
        @keyframes opacity-change {
          0% {
            opacity: 1
          }
          10% {
            opacity: .7
          }
          23% {
            opacity: .3
          }
          40% {
            opacity: .8
          }
          70% {
            opacity: .1
          }
          80% {
            opacity: .8
          }
          90% {
            opacity: .5
          }
          100% {
            opacity: 1
          }
        }
      }
    }
  }
</style>