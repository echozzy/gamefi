<template>
    <div class="header-con fixed">
        <div class="navigation-bar">
            <div class="nav-con">
                <!-- <div class="nav-item nav-item-left"><span>Home</span></div> -->
                <div class="nav-item"><span>Staking</span></div >
                <div class="nav-item"></div>
                <div class="nav-item"><span>MarketPlace</span></div>
            </div>
            <div class="logo">
                <img src="../assets/home/banner-logo.svg" alt="">
            </div>
        </div>
    </div>
</template>

<script>
import { ref } from '@vue/reactivity'
import { onMounted } from '@vue/runtime-core'
export default {
    name:'MobiePageHeader',
    props: {
        nowActive: {
        type: String,
        default: 'home'
        }
    },
    setup(props) {
        const nav_active = ref(null)
        onMounted(()=>{
            nav_active.value = props.nowActive
        })
        function toggleMenus(nav) {
            if(nav_active.value==null){
                nav_active.value = nav
            }else{
                if(nav_active.value == nav){
                    nav_active.value = null
                }else{
                    nav_active.value = nav
                }
            }
        }

        return {nav_active,toggleMenus}
    },
}
</script>

<style lang="less" scoped>
@media screen and (min-width: 0px) and (max-width: 856px){
    @font-face{
        font-family: NovaBattle;
        src: url('../assets/font/novabattlePro.ttf');
    }
    .header-con{
        width: 100%;
        display: flex;
        justify-content: center;
        font-size: 0.14rem;
        z-index: 99;
        .navigation-bar{
            background: url(../assets/mobie/mobel-logo.svg) no-repeat;
            background-size:100%;
            height: 1.15rem;
            position: relative;
            width: 100%;
            padding: 0 0.2rem;
            .nav-con{
                height: 1rem;
                display: flex;
                align-items: center;
                .nav-item{
                    width: 33%;
                    text-align: center;
                    cursor: pointer;
                    font-weight: 800;
                    span{
                        color: #6C9EC5;
                        font-size: 0.28rem;
                    }
                    &.active{
                        border-bottom: 2px solid #0661dc;
                    }
                    .toggle-icon-con{
                        position: absolute;
                        bottom: 0;
                        left: 50%;
                        transform: translateX(-50%);
                    }
                    .child-ul{
                        z-index: 99;
                        position: absolute;
                        top: 0.05rem;
                        left: 50%;
                        transform: translateX(-50%);
                        background: #111111;
                        padding: 0 0.2rem;
                        max-height: 0;
                        -webkit-transition: max-height 0.5s cubic-bezier(0.48, 0.43, 0.29, 1.3);
                        transition: max-height 0.5s cubic-bezier(0.48, 0.43, 0.29, 1.3);
                        overflow: hidden;
                        .child-nav:first-child{
                            padding-top: 20px;
                        }
                        .child-nav{
                            padding-bottom: 20px;
                            white-space: nowrap;
                        }
                        &.is_show{
                            max-height: 35vh;
                        }
                    }
                }
                .nav-item:hover{
                    span{
                        color:#fff;
                    }
                }
                .nav-item-left{
                    margin-left: 40px;
                }
                .nav-item-right{
                    margin-right: 40px;
                }
            }
            .logo{
                position: absolute;
                left: 50%;
                transform: translateX(-50%);
                width: 2.6rem;
                height: 0.7rem;
                bottom: 0.1rem;
            }
        }
    }
}
</style>