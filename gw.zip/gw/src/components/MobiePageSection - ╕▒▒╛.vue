<template>
  <div class="view-container">
    <div class="top-breathing-con">
      <div class="top-breathing" :class="rolls.value != 0 ? 'top-breathing' : 'top-breathing top-hide'">
        <div class="bg-left breathing">
          <div class="bottom flex">
            <div class="background-left-line"><img src="../assets/home/bg/background_left_line.png" alt=""></div>
            <div class="item1">
              <div class="background-left-x"><img src="../assets/home/bg/background_left_x.png" alt=""></div>
              <div class="background-left-rule"><img src="../assets/home/bg/background_right_rule.png" alt=""></div>
              <div class="background-left-ling"><img src="../assets/home/bg/backgroun-ling.png" alt=""></div>
            </div>
          </div>
        </div>
        <div class="mid"></div>
        <div class="bg-right breathing">
          <div class="bottom-right flex">
            <div class="background-right-line"><img src="../assets/home/bg/background_right_line.png" alt=""></div>
            <div class="item1">
              <div class="background-right-x"><img src="../assets/home/bg/background_right_x.png" alt=""></div>
              <div class="background-right-rule"><img src="../assets/home/bg/background_left_rule.png" alt=""></div>
              <div class="background-left-ling"><img src="../assets/home/bg/backgroun-ling.png" alt=""></div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <div
      class="section-container"
      ref="sectiondom"
      :style="
        `transform: translateY(` +
        translateY +
        `vh); transition-duration: 500ms;`
      "
    >
      <slot></slot>
    </div>
  </div>
</template>

<script>
import { ref,onMounted,reactive } from "vue";
export default {
  name: "MobiePageSection",
  setup(){
    const sectiondom = ref(null)
    onMounted(() => {
      window.addEventListener("mousewheel", handleScroll, true);
      maxHeight.value = -(sectiondom.value.children.length-1)*100
    })
    const translateY = ref(0)
    const isScroll = ref(false)
    const maxHeight = ref(0)
    const rolls = reactive({
      value: 0,
    });

    function handleScroll(e) {
      if (isScroll.value) {
        return;
      }
      isScroll.value = true;
      setTimeout(() => {
        isScroll.value = false;
      }, 500);
      // 向哪个方向滚动
      if (e.deltaY > 0) {
        //   向下滚动
        if(translateY.value <= maxHeight.value){
          return;
        }
        translateY.value -= 100;
      } else {
        // 向上滚动
        if (translateY.value >= 0) {
          return;
        }
        translateY.value += 100;
      }
      sessionStorage.setItem('dataroll', JSON.stringify(translateY.value));
      rolls.value = translateY.value
    }
    return {
      handleScroll,sectiondom,translateY,rolls
    }
  },
  methods:{
    changes(e){
      //直接跳转
      this.translateY = e;
      //动画参数判断
      this.rolls.value =e;
      //动画参数传值给父页面
      this.$emit("srollY",e);
    }
  }

};
</script>

<style lang="less">
  @media screen and (min-device-width: 0px) and (max-device-width: 1200px){
    .top-hide{
      display: none!important;
    }
    .view-container {
      width: 100%;
      height: 100vh;
      overflow-y: hidden;
      background: url(../assets/mobie/mobie-gb.png) no-repeat;
      background-size: 95% 97%;
      background-attachment:fixed;
      background-position:center;
      position: relative;
      .section-container {
        width: 100%;
        overflow: hidden;
        position: absolute;
        z-index: 1;
        .section {
          width: 100%;
          height: 100vh;
          display: flex;
          justify-content: center;
        }
      }

    }
  }
</style>